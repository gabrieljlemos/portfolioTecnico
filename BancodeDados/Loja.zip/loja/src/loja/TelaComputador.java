package loja;

import javax.swing.JOptionPane;

public class TelaComputador extends javax.swing.JFrame {

    public TelaComputador() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        Bvisualiza1 = new javax.swing.JButton();
        Bvisualiza3 = new javax.swing.JButton();
        Bvisualiza2 = new javax.swing.JButton();
        bvisualiza5 = new javax.swing.JButton();
        Bvisualiza6 = new javax.swing.JButton();
        Bvisualiza4 = new javax.swing.JButton();
        Bfechar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        Bvalores = new javax.swing.JButton();

        jPanel5.setBackground(new java.awt.Color(204, 204, 204));

        jPanel6.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel5Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel5Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Bvisualiza1.setText("PC Home");
        Bvisualiza1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Bvisualiza1ActionPerformed(evt);
            }
        });

        Bvisualiza3.setText("PC Streamer 1");
        Bvisualiza3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Bvisualiza3ActionPerformed(evt);
            }
        });

        Bvisualiza2.setText("PC Esports");
        Bvisualiza2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Bvisualiza2ActionPerformed(evt);
            }
        });

        bvisualiza5.setText("PC Editor");
        bvisualiza5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bvisualiza5ActionPerformed(evt);
            }
        });

        Bvisualiza6.setText("PC Master Race");
        Bvisualiza6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Bvisualiza6ActionPerformed(evt);
            }
        });

        Bvisualiza4.setText("PC Streamer 2");
        Bvisualiza4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Bvisualiza4ActionPerformed(evt);
            }
        });

        Bfechar.setText("Fechar");
        Bfechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BfecharActionPerformed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagem/Pc1.png"))); // NOI18N

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagem/Pc3.png"))); // NOI18N

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagem/Pc2.png"))); // NOI18N

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagem/pc5.png"))); // NOI18N

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagem/pc4.png"))); // NOI18N

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagem/pc6.png"))); // NOI18N

        Bvalores.setText("Obter Valores");
        Bvalores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BvaloresActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(Bvisualiza4))
                            .addComponent(jLabel6)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(Bvisualiza1)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(bvisualiza5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Bvisualiza2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Bfechar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Bvalores, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel4)
                                .addComponent(jLabel5)))
                        .addGap(46, 46, 46)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Bvisualiza3)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(Bvisualiza6))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Bvisualiza2)
                    .addComponent(Bvisualiza3)
                    .addComponent(Bvisualiza1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(2, 2, 2))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 159, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Bvisualiza6)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(bvisualiza5)
                        .addComponent(Bvisualiza4)))
                .addGap(18, 18, Short.MAX_VALUE)
                .addComponent(Bvalores, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Bfechar, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Bvisualiza1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Bvisualiza1ActionPerformed
        String result1 = AcessoBd.visualizaPCHome("cod", "processador", "placa_mae", "memoria_ram", "placa_de_video", "armazenamento", "fonte", "gabinete");
        JOptionPane.showMessageDialog(this, result1);

    }//GEN-LAST:event_Bvisualiza1ActionPerformed

    private void BfecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BfecharActionPerformed
        this.dispose();
    }//GEN-LAST:event_BfecharActionPerformed

    private void BvaloresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BvaloresActionPerformed
        String result = AcessoBd.visualizaPC("teste", "nome", "qtd", "preco");
        JOptionPane.showMessageDialog(this, result);
    }//GEN-LAST:event_BvaloresActionPerformed

    private void Bvisualiza2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Bvisualiza2ActionPerformed
        String result2 = AcessoBd.visualizaPCHome("cod", "processador", "placa_mae", "memoria_ram", "placa_de_video", "armazenamento", "fonte", "gabinete");
        JOptionPane.showMessageDialog(this, result2);    }//GEN-LAST:event_Bvisualiza2ActionPerformed

    private void Bvisualiza3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Bvisualiza3ActionPerformed
        String result3 = AcessoBd.visualizaPCHome("cod", "processador", "placa_mae", "memoria_ram", "placa_de_video", "armazenamento", "fonte", "gabinete");
        JOptionPane.showMessageDialog(this, result3);     }//GEN-LAST:event_Bvisualiza3ActionPerformed

    private void Bvisualiza4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Bvisualiza4ActionPerformed
        String result4 = AcessoBd.visualizaPCHome("cod", "processador", "placa_mae", "memoria_ram", "placa_de_video", "armazenamento", "fonte", "gabinete");
        JOptionPane.showMessageDialog(this, result4);
    }//GEN-LAST:event_Bvisualiza4ActionPerformed

    private void bvisualiza5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bvisualiza5ActionPerformed
        String result5 = AcessoBd.visualizaPCHome("cod", "processador", "placa_mae", "memoria_ram", "placa_de_video", "armazenamento", "fonte", "gabinete");
        JOptionPane.showMessageDialog(this, result5);
    }//GEN-LAST:event_bvisualiza5ActionPerformed

    private void Bvisualiza6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Bvisualiza6ActionPerformed
        String result6 = AcessoBd.visualizaPCHome("cod", "processador", "placa_mae", "memoria_ram", "placa_de_video", "armazenamento", "fonte", "gabinete");
        JOptionPane.showMessageDialog(this, result6);    }//GEN-LAST:event_Bvisualiza6ActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaComputador().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Bfechar;
    private javax.swing.JButton Bvalores;
    private javax.swing.JButton Bvisualiza1;
    private javax.swing.JButton Bvisualiza2;
    private javax.swing.JButton Bvisualiza3;
    private javax.swing.JButton Bvisualiza4;
    private javax.swing.JButton Bvisualiza6;
    private javax.swing.JButton bvisualiza5;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    // End of variables declaration//GEN-END:variables
}
