package loja;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.spi.DirStateFactory;

public class AcessoBd {

    private static Connection connection;

    public static Connection getConnection() {
        if (connection == null) {
            try {

                Class.forName("org.postgresql.Driver");
                String host = "localhost";
                String port = "5432";
                String database = "loja";
                String user = "postgres";
                String pass = "postgres";

                String url = "jdbc:postgresql://" + host + ":" + port + "/" + database;
                connection = DriverManager.getConnection(url, user, pass);

            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }

    public static void close() {
        if (connection == null) {
            throw new RuntimeException("Nenhuma conexão aberta!");
        } else {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static boolean logar(String cpf, String senha, String tabela) {
        try {
            Connection con = AcessoBd.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * from " + tabela);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                if (cpf.equals(rs.getString(2)) && senha.equals(rs.getString(4))) {
                    return true;
                }

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void salvar(Gamer gamer) {
        try {
            Connection con = AcessoBd.getConnection();
            PreparedStatement ps = con.prepareStatement("INSERT INTO gamer (cpf, nome, endereco, senha) values(?, ?, ?, ?)");
            ps.setString(1, gamer.getCpf());
            ps.setString(2, gamer.getNome());
            ps.setString(3, gamer.getEndereco());
            ps.setString(4, gamer.getSenha());
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();

        }
    }

    public static String visualizaPC(String tabela, String... atributos) {
        try {
            Connection con = AcessoBd.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM estoque");
            ResultSet rs = ps.executeQuery();
            String selectfrom = " ";
            while (rs.next()) {

                for (String i : atributos) {
                    selectfrom = selectfrom + "  |  " + rs.getString(i);

                }
                selectfrom = selectfrom + "\n";
            }
            return selectfrom;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return " ";

    }

    public static String visualizaPCHome(String tabela, String... atributos) {
        try {
            Connection con = AcessoBd.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM computadores where cod = '1'");
            ResultSet rs = ps.executeQuery();
            String selectfrom = " ";
            while (rs.next()) {

                for (String i : atributos) {
                    selectfrom = selectfrom + "  |  " + rs.getString(i);

                }
                selectfrom = selectfrom + "\n";
            }
            return selectfrom;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return " ";

    }

    public static String visualizaPCEsports(String tabela, String... atributos) {
        try {
            Connection con = AcessoBd.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM computadores where cod = '2'");
            ResultSet rs = ps.executeQuery();
            String selectfrom = " ";
            while (rs.next()) {

                for (String i : atributos) {
                    selectfrom = selectfrom + "  |  " + rs.getString(i);

                }
                selectfrom = selectfrom + "\n";
            }
            return selectfrom;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return " ";

    }

    public static String visualizaPCStreamer(String tabela, String... atributos) {
        try {
            Connection con = AcessoBd.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM computadores where cod = '3'");
            ResultSet rs = ps.executeQuery();
            String selectfrom = " ";
            while (rs.next()) {

                for (String i : atributos) {
                    selectfrom = selectfrom + "  |  " + rs.getString(i);

                }
                selectfrom = selectfrom + "\n";
            }
            return selectfrom;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return " ";

    }

    public static String visualizaPCStreamer2(String tabela, String... atributos) {
        try {
            Connection con = AcessoBd.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM computadores where cod = '4'");
            ResultSet rs = ps.executeQuery();
            String selectfrom = " ";
            while (rs.next()) {

                for (String i : atributos) {
                    selectfrom = selectfrom + "  |  " + rs.getString(i);

                }
                selectfrom = selectfrom + "\n";
            }
            return selectfrom;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return " ";

    }

    public static String visualizaPCEditor(String tabela, String... atributos) {
        try {
            Connection con = AcessoBd.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM computadores where cod = '5'");
            ResultSet rs = ps.executeQuery();
            String selectfrom = " ";
            while (rs.next()) {

                for (String i : atributos) {
                    selectfrom = selectfrom + "  |  " + rs.getString(i);

                }
                selectfrom = selectfrom + "\n";
            }
            return selectfrom;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return " ";

    }

    public static String visualizaPCMasterRace(String tabela, String... atributos) {
        try {
            Connection con = AcessoBd.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM computadores where cod = '6'");
            ResultSet rs = ps.executeQuery();
            String selectfrom = " ";
            while (rs.next()) {

                for (String i : atributos) {
                    selectfrom = selectfrom + "  |  " + rs.getString(i);

                }
                selectfrom = selectfrom + "\n";
            }
            return selectfrom;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return " ";

    }
}
