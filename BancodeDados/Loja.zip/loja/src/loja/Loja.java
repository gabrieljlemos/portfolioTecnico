package loja;

public class Loja {

    public static void main(String[] args) {
        TelaUm tela = new TelaUm();
        tela.setVisible(true);

    }

}
