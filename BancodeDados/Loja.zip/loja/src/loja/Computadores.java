
package loja;

public class Computadores {
    int id;
    String processador;
    String placa_mae;
    String memoria_ram;
    String placa_de_video;
    String armazenamento;
    String fonte;
    String gabinete;
    Boolean sistema_instalado;

    public Computadores(int id, String processador, String placa_mae, String memoria_ram, String placa_de_video, String armazenamento, String fonte, String gabinete, Boolean sistema_instalado) {
        this.id = id;
        this.processador = processador;
        this.placa_mae = placa_mae;
        this.memoria_ram = memoria_ram;
        this.placa_de_video = placa_de_video;
        this.armazenamento = armazenamento;
        this.fonte = fonte;
        this.gabinete = gabinete;
        this.sistema_instalado = sistema_instalado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProcessador() {
        return processador;
    }

    public void setProcessador(String processador) {
        this.processador = processador;
    }

    public String getPlaca_mae() {
        return placa_mae;
    }

    public void setPlaca_mae(String placa_mae) {
        this.placa_mae = placa_mae;
    }

    public String getMemoria_ram() {
        return memoria_ram;
    }

    public void setMemoria_ram(String memoria_ram) {
        this.memoria_ram = memoria_ram;
    }

    public String getPlaca_de_video() {
        return placa_de_video;
    }

    public void setPlaca_de_video(String placa_de_video) {
        this.placa_de_video = placa_de_video;
    }

    public String getArmazenamento() {
        return armazenamento;
    }

    public void setArmazenamento(String armazenamento) {
        this.armazenamento = armazenamento;
    }

    public String getFonte() {
        return fonte;
    }

    public void setFonte(String fonte) {
        this.fonte = fonte;
    }

    public String getGabinete() {
        return gabinete;
    }

    public void setGabinete(String gabinete) {
        this.gabinete = gabinete;
    }

    public Boolean getSistema_instalado() {
        return sistema_instalado;
    }

    public void setSistema_instalado(Boolean sistema_instalado) {
        this.sistema_instalado = sistema_instalado;
    }     
}
