package com.example.matrizes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button botaoCalculo;
    EditText zero_zero, zero_um, zero_dois;
    EditText um_zero, um_um, um_dois;
    EditText dois_zero, dois_um, dois_dois;
    TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        botaoCalculo = findViewById(R.id.botaoCalculo);
        resultText = findViewById(R.id.textoResultado);
        zero_zero = findViewById(R.id.zero_zero);
        zero_um = findViewById(R.id.zero_um);
        zero_dois = findViewById(R.id.zero_dois);
        um_zero = findViewById(R.id.um_zero);
        um_um = findViewById(R.id.um_um);
        um_dois = findViewById(R.id.um_dois);
        dois_zero = findViewById(R.id.dois_zero);
        dois_um = findViewById(R.id.dois_um);
        dois_dois = findViewById(R.id.dois_dois);
    }

    public void Calculo(View v) {
        resultText.setText("Resultado: " + null);

        String szero_zero = zero_zero.getText().toString();
        String szero_um = zero_um.getText().toString();
        String szero_dois = zero_dois.getText().toString();
        String sum_zero = um_zero.getText().toString();
        String sum_um = um_um.getText().toString();
        String sum_dois = um_dois.getText().toString();
        String sdois_zero = dois_zero.getText().toString();
        String sdois_um = dois_um.getText().toString();
        String sdois_dois = dois_dois.getText().toString();

        //
        if (szero_zero.equals("") || szero_um.equals("") || szero_dois.equals("") || sum_zero.equals("") || sum_um.equals("") || sum_dois.equals("") || sdois_zero.equals("") || sdois_um.equals("") || sdois_dois.equals("")) {
            resultText.setText("Preencha todos os valores!");
        } else {
            int zero_zero = Integer.parseInt(szero_zero);
            int zero_um = Integer.parseInt(szero_um);
            int zero_dois = Integer.parseInt(szero_dois);
            int um_zero = Integer.parseInt(sum_zero);
            int um_um = Integer.parseInt(sum_um);
            int um_dois = Integer.parseInt(sum_dois);
            int dois_zero = Integer.parseInt(sdois_zero);
            int dois_um = Integer.parseInt(sdois_um);
            int dois_dois = Integer.parseInt(sdois_dois);

            int determinante = zero_zero * um_um * dois_dois + zero_um * um_dois * dois_zero + zero_dois * um_zero * dois_um - zero_um * um_zero * dois_dois - zero_zero * um_dois * dois_um - zero_dois * um_um * dois_zero;
            resultText.setText("Resultado: " + determinante);
            //Toast.makeText(this,"Resultado"+determinante, Toast.LENGTH_LONG).show();
        }
    }
}